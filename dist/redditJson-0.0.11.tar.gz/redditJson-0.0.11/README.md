# redditJson
Uses the reddit api to gather user generated posts for a specific subreddit.
